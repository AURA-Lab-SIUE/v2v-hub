# Your White Paper template (MC 501)

This folder is your White Paper, already set up. Each file is one part of the paper, and each
part matches one row of the [White Paper and conference poster rubric](https://aura-lab.siue.edu/v2v-hub/resources/rubrics/MC501-rubric-white-paper-and-conference-poster.pdf).
You paste your writing and your code into the matching file, and the paper renders.

## Step 1: Put this folder in your workspace

The folder named `white-paper` goes in the top folder of your workspace, next to `README.md`
and your `data` folder, the same place your worksheets go. The guide
[Put a Worksheet in Your Workspace](https://aura-lab.siue.edu/v2v-hub/guides/mc501/14-put-a-worksheet-in-your-workspace.html)
shows each click; move the whole `white-paper` folder the way it moves one file.

You should see: in VS Code's **Explorer** (the file list on the left), `white-paper` listed
with `data` and `README.md`. Click it once to see the files below.

## Step 2: Put your title and name in

Click `_quarto.yml`. Change `Your White Paper's Title` and `Your Name` to your own, keeping
the quote marks. Click **File**, then **Save**.

## Step 3: Paste each part into its file

Open each file and read its gray note, the text between `<!--` and `-->`. The note says what
goes there and what the rubric looks for. The notes never show in your paper.

| File | Part of the paper | Rubric points | Paste from |
|---|---|---|---|
| `index.qmd` | Abstract, and the name of your citation style | 15, with references | write it last |
| `01-introduction.qmd` | Introduction and framing | 25 | Research Proposal |
| `02-methods.qmd` | Methods, with the three transparency markers | 55 | Research Proposal, Extended Codebook and Reliability Protocol, Sampling Plan and Pilot |
| `03-results.qmd` | Results: tables, figures, one test per question, the robustness check | 40 | your own-study code |
| `04-discussion.qmd` | Discussion | 40 | new writing |
| `05-reflection.qmd` | Reflection | 10 | new writing |
| `references.qmd` | References | 15, with the abstract | every source you cite |
| `appendix-codebook.qmd` | Appendix A, your codebook | part of Methods | your final codebook |

The last rubric row, Reproducibility and publication (15 points), is earned in Steps 5 and 6:
the paper renders, and every number comes from the code.

## Step 4: Paste your code into the Results

Copy a chunk from your worksheet, from its first line (three backticks and `{r}`) down to its
closing three backticks, and paste it under the Results heading where its output belongs.

Your worksheet's lines work here unchanged. A line such as
`analysis <- read_rds("data/my_analysis.RDS")` reads the file from the `data` folder in your
workspace's top folder, because `_quarto.yml` tells the paper to run its code from there.

The line that reads your data goes once, in the `setup` chunk at the top of `03-results.qmd`,
under the two `library()` lines.

## Step 5: Write numbers that come from the code

A number you type by hand goes stale when your data changes, and the rubric takes points for
it. Write the number as inline code instead: a backtick, the letter `r`, a space, the code,
and a closing backtick. In `03-results.qmd`, under the setup chunk, the sentence

> The sample held \`r nrow(analysis)\` posts.

renders as "The sample held 120 posts." with your real count in place of 120. That works in
the file whose setup chunk loaded `analysis`. To use a number in another file, such as the
abstract, copy the same setup chunk to the top of that file.

## Step 6: Render the paper

In the R terminal (the panel at the bottom of VS Code whose last line shows `>`), type this
line and press **Enter**:

```r
quarto::quarto_render("white-paper")
```

You should see: a stream of lines about each part, then `Output created: docs/index.html`.
Your paper's PDF is now `white-paper.pdf`, in the `docs` folder inside `white-paper`.

If the render stops, the last lines name the file and the line. Fix that line, save, and run
it again. `No TeX installation was detected` means the PDF tool is missing: Step 3 of the
[Chapter 14 starter file](https://aura-lab.siue.edu/v2v-hub/starters/14-publishing-your-paper.qmd)
installs it.

## Step 7: Publish

Commit and push ([Commit and Push with Git](https://aura-lab.siue.edu/v2v-hub/guides/mc501/12-commit-and-push-with-git.html)),
then type this line in the R terminal and press **Enter**:

```r
v2v::deploy_portfolio("white-paper")
```

When it asks `Publish to GitHub Pages? [y/N]`, click in the R terminal, type `y`, and press
**Enter**. The guide [Publish Your Site](https://aura-lab.siue.edu/v2v-hub/guides/mc501/13-publish-your-site.html)
covers what each message means.

## Your poster

`poster-template.pptx`, in this folder, is your conference poster already laid out: one
PowerPoint slide, 48 by 36 inches, with a box for each block and its type size set. Open it,
replace the text in each box with that block's short version from your paper, and add your
chart and QR code. The guide [Build Your Conference Poster](https://aura-lab.siue.edu/v2v-hub/guides/mc501/18-build-your-conference-poster.html)
makes the QR code (Part 1), and its Part 3 and Part 4 cover the chart and the PDF; with this
file you skip Part 2.

## What you submit

One ZIP file holding `white-paper.pdf`, your poster PDF, and your AI-use log, plus your site's address pasted
into the Blackboard submission. The [assignments page](https://aura-lab.siue.edu/v2v-hub/mc501-assignments.html#white-paper-and-conference-poster)
has the details.
